# pgms
Programs, typically contributed by users as a part of illustrating a feature or pointing to potential issues. These are not as curated as examples and tests in the charm repo are (or should be). Currently, not requiring any reviews (but may raise to 1 review). Also.. will not trigger CI. 
